# Install the required libraries
packages <- c("tidyverse", "irr", "psych", "readxl")
for (p in packages) {
  if (!requireNamespace(p, quietly = TRUE)) {
    install.packages(p, dependencies = TRUE)
  }
  library(p, character.only = TRUE)
}

# Read the file from the downloads folder
rel_data <- read_excel("/Users/ayoolabimpec/Downloads/MeasurementChapterEFA/Reliability/reliabilityDataset.xlsx")

# Select the necessary columns to analyze
rel1_data <- select(rel_data, 'Size.LOC.Designite', 'Size.LOC.JHawk', 'Size.LOC.Understand')


# Calculate Cronbach Alpha using the 'psych' package
alphaResult <- alpha(rel1_data)

# Optionally, print the result
print(alphaResult)
